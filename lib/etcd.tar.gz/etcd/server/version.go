package server

const Version = "v2"
