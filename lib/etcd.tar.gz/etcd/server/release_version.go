package server

const ReleaseVersion = "0.3.0+git"
