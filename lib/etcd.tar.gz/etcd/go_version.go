// +build !go1.2

"etcd requires go 1.2 or greater to build"
