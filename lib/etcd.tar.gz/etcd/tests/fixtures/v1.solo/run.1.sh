#!/bin/sh

./build
./etcd -d tmp/node0 -n node0
