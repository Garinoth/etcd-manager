package raft

/*
import (
	"testing"
	"time"
)

func TestGC(t *testing.T) {
	<-time.After(500 * time.Millisecond)
	panic("Oh god no!")
}
*/
