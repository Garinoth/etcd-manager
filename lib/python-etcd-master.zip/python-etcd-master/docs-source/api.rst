API Documentation
=========================
.. automodule:: etcd
   :members:
.. autoclass:: Client
   :special-members:
   :members:
   :exclude-members: __weakref__
.. autoclass:: Lock
   :special-members:
   :members:
   :exclude-members: __weakref__
